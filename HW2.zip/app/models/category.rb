class Category < ActiveRecord::Base

end